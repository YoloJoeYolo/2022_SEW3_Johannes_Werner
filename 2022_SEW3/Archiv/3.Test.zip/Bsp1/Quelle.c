#include <time.h>
#include <stdio.h>
#include <string.h>

char haeufigstesZeichen(text) {
	int counter[30];
	for (int i = 0; i < 30; i++)
	{
		counter[i] = 0;
	}
	char abc = "abcdefghijklmnopqrstuvwxyz";
	for (int i = 0; i < strlen(text); i++)
	{
		for (int j = 0; j < strlen(&abc); j++)
		{
			if (abc[&j] == text[&i])
			{
				counter[j] += 1;
			}
		}
	}
	int topChar = -1;
	int numberOfTopChars = -1;
	for (int i = 0; i < 30; i++)
	{
		if (numberOfTopChars < counter[i])
		{
			topChar = i;
			numberOfTopChars = counter[i];
		}
	}
	if (topChar == -1)
	{
		return ' ';
	}
	return topChar;
}

void main() {
	char text[] = "Hallo, dies ist ein einfacher Beispieltext. Dieser hat keinen Zweck, steht also nur so zum Selbstzweck da.";
	char top = haeufigstesZeichen(text);
	printf("%c", top);
}