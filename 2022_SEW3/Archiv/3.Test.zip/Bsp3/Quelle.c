#define _CRT_SECURE_NO_WARNINGS
#include <time.h>
#include <stdio.h>

void main() {
	char name[201];
	printf("Geben Sie Ihren Namen ein: ");
	fgets(name, 200, stdin);

	float numbers[6];
	double average = 0;
	for (int i = 0; i < 6; i++)
	{
		printf("Geben Sie die %i Zahl ein: ", i+1);
		scanf("%f", &numbers[i]);
		average += numbers[i];
	}

	printf("%s\n", name);
	
	average = average / 6;
	for (int i = 0; i < 6; i++)
	{
		if (numbers[i] > average)
		{
			printf("%f\n", numbers[i]);
		}
	}
}