#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>

void main() {
	printf("Geben Sie etwas ein: ");
	char text[1025];
	fgets(text, 1024, stdin);
	int counter = 0;
	for (int i = 0; i < strlen(text); i++)
	{
		if (text[i] == 'e' || text[i] == 'E')
		{
			counter++;
		}
	} 
	printf("Es kommt %i mal e/E vor ", counter);  
}