#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#define lengthABC 98

void einfachesVorkommen(char text[]) {
	static char abc[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789^!\"�$%&/()=?��{[]}\\`�+*~#',.-;:_<>| ";
	int counter[lengthABC];

		for (int i = 0; i < lengthABC; i++)
	{
		counter[i] = 0;
	}

	for (int i = 0; i < strlen(text); i++)
	{
		for (int j = 0; j < lengthABC; j++)
		{
			if (abc[j] == text[i])
			{
				counter[j] += 1;
			}
		}
	}
	int onlyOnce = 0;
	for (int i = 0; i < lengthABC; i++)
	{
		if (counter[i] == 1)
		{
			printf("%c", abc[i]);
			onlyOnce++;
		}
	}
	printf("\nEs kommen %i Zeichen nur einmal im Text vor.", onlyOnce);
}

void main() {
	char text[] = "Hallo, dies ist ein einfacher Beispieltext. Dieser hat keinen Zweck, steht also nur so zum Selbstzweck da.";
	einfachesVorkommen(text);
}