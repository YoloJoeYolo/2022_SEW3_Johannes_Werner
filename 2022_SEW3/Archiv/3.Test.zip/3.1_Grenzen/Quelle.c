#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#define arrayGroe�e 5

void main() {
	char name[201];
	printf("Geben Sie Ihren Namen ein: ");
	fgets(name, 200, stdin);

	float upperLimit;
	float lowerLimit;

	printf("Geben Sie die Obergrenze ein: ");
	scanf("%f", &upperLimit);
	printf("Geben Sie die Untergrenze ein: ");
	scanf("%f", &lowerLimit);
	
	float numbers[arrayGroe�e];
	for (int i = 0; i < arrayGroe�e; i++)
	{
		printf("Geben Sie die %i Zahl ein: ", i + 1);
		scanf("%f", &numbers[i]);
	}

	printf("%s\n", name);

	for (int i = 0; i < arrayGroe�e; i++)
	{
		if (numbers[i] <= upperLimit && numbers[i] >= lowerLimit)
		{
			printf("%f\n", numbers[i]);
		}
	}
}